"use client"

interface KeyboardProps {
  guessedLetters: Set<string>
  correctLetters: Set<string>
  onLetterClick: (letter: string) => void
  disabled: boolean
}

const ALPHABET = "ABCDEFGHIJKLMNOPQRSTUVWXYZ".split("")

export function Keyboard({ guessedLetters, correctLetters, onLetterClick, disabled }: KeyboardProps) {
  const getButtonStyle = (letter: string) => {
    if (!guessedLetters.has(letter)) {
      return "bg-white border-2 border-[#e5e5e5] text-[#333333] hover:border-[#F6CEA0] hover:bg-[#F6CEA0]/10 hover:shadow-md hover:scale-105 active:scale-95"
    }
    if (correctLetters.has(letter)) {
      return "bg-gradient-to-br from-[#F6CEA0] to-[#f0c490] text-white border-2 border-[#F6CEA0] shadow-sm"
    }
    return "bg-[#f5f5f5] text-[#cccccc] border-2 border-[#f0f0f0] opacity-50"
  }

  return (
    <div className="grid grid-cols-7 md:grid-cols-9 gap-2 max-w-2xl mx-auto">
      {ALPHABET.map((letter) => {
        const isGuessed = guessedLetters.has(letter)
        const isDisabled = disabled || isGuessed

        return (
          <button
            key={letter}
            onClick={() => onLetterClick(letter)}
            disabled={isDisabled}
            className={`
              aspect-square rounded-xl text-sm md:text-base font-bold
              transition-all duration-200 disabled:cursor-not-allowed
              ${getButtonStyle(letter)}
            `}
          >
            {letter}
          </button>
        )
      })}
    </div>
  )
}
