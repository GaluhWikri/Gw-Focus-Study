interface WordPuzzleProps {
  word: string
  guessedLetters: Set<string>
}

export function WordPuzzle({ word, guessedLetters }: WordPuzzleProps) {
  return (
    <div className="flex justify-center items-center min-h-[140px]">
      <div className="flex flex-wrap justify-center gap-3 md:gap-5">
        {word.split("").map((letter, index) => (
          <div
            key={index}
            /* Enhanced letter boxes with rounded borders, subtle shadow, and animations */
            className="w-14 h-20 md:w-20 md:h-24 flex items-center justify-center border-b-4 border-[#e5e5e5] rounded-t-lg bg-white shadow-sm"
          >
            {guessedLetters.has(letter) ? (
              /* Added animation class for letter reveal */
              <span className="text-4xl md:text-6xl font-bold text-[#F6CEA0] animate-in fade-in zoom-in duration-300">
                {letter}
              </span>
            ) : (
              <span className="text-4xl md:text-6xl font-bold text-transparent">_</span>
            )}
          </div>
        ))}
      </div>
    </div>
  )
}
