"use client"

interface GameOverModalProps {
  status: "won" | "lost"
  word: string
  onNextWord: () => void
  onReset: () => void
}

export function GameOverModal({ status, word, onNextWord, onReset }: GameOverModalProps) {
  return (
    <div className="fixed inset-0 bg-black/30 backdrop-blur-md flex items-center justify-center p-6 z-50 animate-in fade-in duration-300">
      <div className="bg-white rounded-3xl p-10 md:p-14 max-w-md w-full space-y-8 shadow-2xl animate-in zoom-in duration-300">
        {status === "won" ? (
          <>
            <div className="text-center space-y-4">
              <h2 className="text-4xl md:text-5xl font-bold text-[#333333] tracking-tight">You solved it!</h2>
              <p className="text-[#999999] text-lg font-medium">The word was</p>
              <p className="text-3xl md:text-4xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-[#F6CEA0] to-[#f0c490]">
                {word}
              </p>
            </div>

            <div className="space-y-3">
              <button
                onClick={onNextWord}
                className="w-full bg-gradient-to-r from-[#F6CEA0] to-[#f0c490] text-white px-8 py-5 rounded-2xl text-lg font-bold hover:shadow-lg hover:scale-[1.02] active:scale-95 transition-all duration-200"
              >
                Next Word
              </button>
              <button
                onClick={onReset}
                className="w-full bg-white border-2 border-[#e5e5e5] text-[#333333] px-8 py-5 rounded-2xl text-lg font-semibold hover:border-[#F6CEA0] hover:bg-[#F6CEA0]/5 hover:shadow-md hover:scale-[1.02] active:scale-95 transition-all duration-200"
              >
                Change Category
              </button>
            </div>
          </>
        ) : (
          <>
            <div className="text-center space-y-4">
              <h2 className="text-4xl md:text-5xl font-bold text-[#333333] tracking-tight">Out of guesses</h2>
              <p className="text-[#999999] text-lg font-medium">The word was</p>
              <p className="text-3xl md:text-4xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-[#F6CEA0] to-[#f0c490]">
                {word}
              </p>
            </div>

            <div className="space-y-3">
              <button
                onClick={onNextWord}
                className="w-full bg-gradient-to-r from-[#F6CEA0] to-[#f0c490] text-white px-8 py-5 rounded-2xl text-lg font-bold hover:shadow-lg hover:scale-[1.02] active:scale-95 transition-all duration-200"
              >
                Try Again
              </button>
              <button
                onClick={onReset}
                className="w-full bg-white border-2 border-[#e5e5e5] text-[#333333] px-8 py-5 rounded-2xl text-lg font-semibold hover:border-[#F6CEA0] hover:bg-[#F6CEA0]/5 hover:shadow-md hover:scale-[1.02] active:scale-95 transition-all duration-200"
              >
                Change Category
              </button>
            </div>
          </>
        )}
      </div>
    </div>
  )
}
