interface LivesIndicatorProps {
  lives: number
  maxLives: number
}

export function LivesIndicator({ lives, maxLives }: LivesIndicatorProps) {
  return (
    <div className="flex items-center gap-3">
      {Array.from({ length: maxLives }).map((_, index) => (
        <div
          key={index}
          /* Enhanced circles with shadows and smooth animations */
          className={`
            w-4 h-4 md:w-5 md:h-5 rounded-full transition-all duration-300
            ${
              index < lives
                ? "bg-gradient-to-br from-[#F6CEA0] to-[#f0c490] shadow-md scale-100"
                : "bg-white border-2 border-[#e5e5e5] scale-90"
            }
          `}
        />
      ))}
    </div>
  )
}
