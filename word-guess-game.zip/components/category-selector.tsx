"use client"

interface Category {
  id: string
  label: string
  keyword: string
}

interface CategorySelectorProps {
  categories: Category[]
  onSelect: (categoryId: string) => void
}

export function CategorySelector({ categories, onSelect }: CategorySelectorProps) {
  return (
    <div className="w-full max-w-md space-y-10">
      <div className="text-center space-y-4">
        <h2 className="text-4xl md:text-5xl font-semibold text-[#333333] tracking-tight">Choose a Category</h2>
        <p className="text-[#999999] text-lg">Pick a topic to start guessing</p>
      </div>

      <div className="grid grid-cols-1 gap-3">
        {categories.map((category) => (
          <button
            key={category.id}
            onClick={() => onSelect(category.id)}
            // Added smooth hover effects, shadow, and scale transform
            className="w-full px-8 py-6 bg-white border-2 border-[#e5e5e5] rounded-2xl text-[#333333] text-lg font-semibold hover:border-[#F6CEA0] hover:bg-[#F6CEA0]/5 hover:shadow-md hover:scale-[1.02] transition-all duration-200"
          >
            {category.label}
          </button>
        ))}
      </div>
    </div>
  )
}
