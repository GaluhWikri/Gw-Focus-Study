"use client"

import { useState } from "react"
import { WordPuzzle } from "@/components/word-puzzle"
import { Keyboard } from "@/components/keyboard"
import { LivesIndicator } from "@/components/lives-indicator"
import { GameOverModal } from "@/components/game-over-modal"
import { CategorySelector } from "@/components/category-selector"

const CATEGORIES = [
  {
    id: "animals",
    label: "Animals",
    words: [
      "TIGER",
      "ZEBRA",
      "PANDA",
      "EAGLE",
      "SNAKE",
      "HORSE",
      "WHALE",
      "SHARK",
      "BEARS",
      "LIONS",
      "FOXES",
      "WOLVES",
      "RABBIT",
      "MONKEY",
      "GIRAFFE",
      "LEOPARD",
      "DOLPHIN",
      "PENGUIN",
      "OSTRICH",
      "CAMEL",
    ],
  },
  {
    id: "space",
    label: "Space",
    words: [
      "PLANET",
      "COMET",
      "STARS",
      "LUNAR",
      "ORBIT",
      "SOLAR",
      "VENUS",
      "MARS",
      "SATURN",
      "JUPITER",
      "METEOR",
      "GALAXY",
      "NEBULA",
      "ROCKET",
      "COSMOS",
      "PULSAR",
      "QUASAR",
      "APOLLO",
      "ASTEROID",
      "ECLIPSE",
    ],
  },
  {
    id: "fruits",
    label: "Fruits",
    words: [
      "APPLE",
      "MANGO",
      "GRAPE",
      "LEMON",
      "PEACH",
      "MELON",
      "BERRY",
      "ORANGE",
      "BANANA",
      "CHERRY",
      "PAPAYA",
      "COCONUT",
      "PINEAPPLE",
      "KIWI",
      "PLUM",
      "PEAR",
      "LIME",
      "GUAVA",
      "APRICOT",
      "LYCHEE",
    ],
  },
  {
    id: "ocean",
    label: "Ocean",
    words: [
      "CORAL",
      "WAVES",
      "PEARL",
      "SHORE",
      "TIDE",
      "REEF",
      "KELP",
      "WHALE",
      "SHARK",
      "DOLPHIN",
      "OCTOPUS",
      "JELLYFISH",
      "STARFISH",
      "SEAHORSE",
      "CLAM",
      "SEAL",
      "CRAB",
      "LOBSTER",
      "URCHIN",
      "ALGAE",
    ],
  },
  {
    id: "nature",
    label: "Nature",
    words: [
      "FOREST",
      "RIVER",
      "MOUNTAIN",
      "VALLEY",
      "CANYON",
      "DESERT",
      "MEADOW",
      "JUNGLE",
      "STREAM",
      "PRAIRIE",
      "VOLCANO",
      "CLIFF",
      "LAKE",
      "POND",
      "GRASS",
      "MOSS",
      "FERN",
      "BRANCH",
      "STONE",
      "BOULDER",
    ],
  },
]

const MAX_LIVES = 6

export default function WordGuessGame() {
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null)
  const [currentWord, setCurrentWord] = useState<string>("")
  const [guessedLetters, setGuessedLetters] = useState<Set<string>>(new Set())
  const [lives, setLives] = useState(MAX_LIVES)
  const [gameStatus, setGameStatus] = useState<"playing" | "won" | "lost">("playing")
  const [streak, setStreak] = useState(0)
  const [usedWords, setUsedWords] = useState<Set<string>>(new Set())

  const selectWord = (categoryId: string) => {
    const category = CATEGORIES.find((c) => c.id === categoryId)
    if (!category) return

    // Get unused words
    const availableWords = category.words.filter((word) => !usedWords.has(word))

    // If all words used, reset used words
    if (availableWords.length === 0) {
      setUsedWords(new Set())
      const randomWord = category.words[Math.floor(Math.random() * category.words.length)]
      setCurrentWord(randomWord)
      setUsedWords(new Set([randomWord]))
    } else {
      const randomWord = availableWords[Math.floor(Math.random() * availableWords.length)]
      setCurrentWord(randomWord)
      setUsedWords((prev) => new Set([...prev, randomWord]))
    }

    setGuessedLetters(new Set())
    setLives(MAX_LIVES)
    setGameStatus("playing")
  }

  const handleCategorySelect = (categoryId: string) => {
    setSelectedCategory(categoryId)
    setUsedWords(new Set())
    selectWord(categoryId)
  }

  const handleLetterGuess = (letter: string) => {
    if (guessedLetters.has(letter) || gameStatus !== "playing") return

    const newGuessedLetters = new Set(guessedLetters)
    newGuessedLetters.add(letter)
    setGuessedLetters(newGuessedLetters)

    // Check if letter is in word
    if (!currentWord.includes(letter)) {
      const newLives = lives - 1
      setLives(newLives)
      if (newLives === 0) {
        setGameStatus("lost")
        setStreak(0)
      }
    } else {
      // Check if word is complete
      const allLettersGuessed = currentWord.split("").every((char) => newGuessedLetters.has(char))
      if (allLettersGuessed) {
        setGameStatus("won")
        setStreak((prev) => prev + 1)
      }
    }
  }

  const handleNextWord = () => {
    if (selectedCategory) {
      selectWord(selectedCategory)
    }
  }

  // Reset game
  const handleReset = () => {
    setSelectedCategory(null)
    setCurrentWord("")
    setGuessedLetters(new Set())
    setLives(MAX_LIVES)
    setGameStatus("playing")
    setStreak(0)
    setUsedWords(new Set())
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-white to-[#fafafa] flex flex-col">
      {/* Header */}
      <header className="px-6 py-8 md:py-12">
        <div className="max-w-4xl mx-auto">
          <div className="flex items-center justify-between">
            <h1 className="text-2xl md:text-3xl font-semibold tracking-tight text-[#333333]">Word Guess</h1>
            {streak > 0 && (
              <div className="flex items-center gap-3">
                <span className="text-sm text-[#999999] font-medium">Streak</span>
                <div className="bg-gradient-to-br from-[#F6CEA0] to-[#f0c490] text-white font-bold px-4 py-1.5 rounded-full text-sm shadow-sm">
                  {streak}
                </div>
              </div>
            )}
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="flex-1 flex flex-col items-center justify-center px-6 pb-12">
        {!selectedCategory ? (
          <CategorySelector categories={CATEGORIES} onSelect={handleCategorySelect} />
        ) : (
          <div className="w-full max-w-2xl space-y-12">
            {/* Lives Indicator */}
            <div className="flex justify-center">
              <LivesIndicator lives={lives} maxLives={MAX_LIVES} />
            </div>

            {/* Word Puzzle */}
            <WordPuzzle word={currentWord} guessedLetters={guessedLetters} />

            {/* Keyboard */}
            <Keyboard
              guessedLetters={guessedLetters}
              correctLetters={new Set(currentWord.split(""))}
              onLetterClick={handleLetterGuess}
              disabled={gameStatus !== "playing"}
            />

            {/* Change Category Button */}
            <div className="flex justify-center pt-4">
              <button onClick={handleReset} className="text-sm text-[#999999] hover:text-[#333333] transition-colors">
                Change Category
              </button>
            </div>
          </div>
        )}
      </main>

      {/* Game Over Modal */}
      {gameStatus !== "playing" && (
        <GameOverModal status={gameStatus} word={currentWord} onNextWord={handleNextWord} onReset={handleReset} />
      )}
    </div>
  )
}
